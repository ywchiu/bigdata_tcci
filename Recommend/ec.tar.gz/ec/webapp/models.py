from django.db import models

# Create your models here.
class ecproduct(models.Model):
   productid = models.IntegerField()
   Description = models.CharField(max_length = 100)
